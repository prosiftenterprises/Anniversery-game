# Anniversary Quiz Game — Multiplayer

A two-player "How well do we know each other" quiz game. One person hosts a
room, the other joins with a room code, and both play from their own phone
in real time.

## What's in here

```
anniversary-quiz-app/
├── public/
│   └── index.html            ← the whole game (UI + game logic)
├── netlify/
│   └── functions/
│       └── storage.js        ← tiny backend that syncs the two players
├── netlify.toml               ← tells Netlify where things are
├── package.json                ← one dependency: @netlify/blobs
└── README.md
```

The original file only worked inside a Claude artifact, because it saved
game state with a Claude-only API (`window.storage`). To make it work as a
real, standalone site, this version:

- Adds a small `window.storage` shim at the top of `index.html` that talks
  to a real backend over HTTP instead.
- Adds `netlify/functions/storage.js`, a Netlify Function that stores that
  data in **Netlify Blobs** (built into every Netlify site — no external
  database or account needed).

Nothing about the quiz itself, the questions, the photos, or the design was
changed — only how the two players' devices sync with each other.

## Deploy it — pick one

### Option A: Netlify CLI (fastest, no GitHub needed)

1. Install the CLI if you don't have it: `npm install -g netlify-cli`
2. From inside this folder, run:
   ```
   netlify deploy --prod
   ```
3. Follow the prompts (log in / create a new site). When it finishes it
   prints your live URL.

### Option B: GitHub + Netlify dashboard

1. Push this folder to a new GitHub repository.
2. In the Netlify dashboard: **Add new site → Import an existing project**,
   pick the repo.
3. Build settings should auto-fill from `netlify.toml`
   (publish directory `public`, functions directory `netlify/functions`).
   Click **Deploy**.

> **Note:** Plain drag-and-drop deploys on Netlify only upload static files
> — they skip the `netlify/functions` folder, which means the multiplayer
> sync won't work. Use Option A or B above so the function gets deployed
> too.

## Playing it

1. Open the deployed site. One person taps **Host**, fills in both names
   and the date, and creates the room — this gives a 5-character room code.
2. The other person taps **Join**, enters that code, and picks their role.
3. Both play from their own device; answers and scores sync automatically
   every couple of seconds.

## Customizing

- Edit the questions in `public/index.html` — search for `DEFAULT_ROUND1`,
  `DEFAULT_ROUND2`, and `DEFAULT_ROUND3` near the top of the game's
  `<script>` block, or use the in-game "Edit Questions" screen before
  starting (host only).
- Swap in your own photos either via that same edit screen (Round Three →
  Add Your Own Photo) or by replacing the base64 images baked into the
  `PHOTOS` object in the file.

## How the storage works, if you're curious

`netlify/functions/storage.js` exposes three tiny endpoints backed by
Netlify Blobs:

- `GET /.netlify/functions/storage?key=room:ABCDE` → `{ value }` or 404
- `POST /.netlify/functions/storage` with `{ key, value }` → saves it
- `DELETE /.netlify/functions/storage?key=...` → removes it

The game polls the room's state every ~2.2 seconds and writes an update
whenever a player answers something, so both phones stay in sync without
needing WebSockets or a database to set up.
