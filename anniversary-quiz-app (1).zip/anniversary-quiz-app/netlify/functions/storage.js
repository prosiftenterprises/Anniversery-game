// Netlify Function: simple shared key/value storage for the Anniversary
// Quiz game, backed by Netlify Blobs. This is what lets the two players'
// devices sync room state, scores, and uploaded photos with each other.
//
// GET    /.netlify/functions/storage?key=room:ABCDE   -> { value: "..." } or 404
// POST   /.netlify/functions/storage   { key, value }  -> { ok: true }
// DELETE /.netlify/functions/storage?key=room:ABCDE   -> { ok: true }

import { getStore } from "@netlify/blobs";

function json(body, status) {
  return new Response(JSON.stringify(body), {
    status: status || 200,
    headers: { "Content-Type": "application/json" }
  });
}

export default async (req) => {
  const store = getStore("anniversary-quiz");
  const url = new URL(req.url);

  try {
    if (req.method === "GET") {
      const key = url.searchParams.get("key");
      if (!key) return json({ error: "missing key" }, 400);

      const value = await store.get(key);
      if (value === null) return json({ error: "not found" }, 404);
      return json({ value: value });
    }

    if (req.method === "POST") {
      const body = await req.json();
      if (!body || !body.key) return json({ error: "missing key" }, 400);

      await store.set(body.key, body.value);
      return json({ ok: true });
    }

    if (req.method === "DELETE") {
      const key = url.searchParams.get("key");
      if (!key) return json({ error: "missing key" }, 400);

      await store.delete(key);
      return json({ ok: true });
    }

    return json({ error: "method not allowed" }, 405);
  } catch (err) {
    return json({ error: "storage failure", detail: String(err) }, 500);
  }
};

export const config = {
  path: "/.netlify/functions/storage"
};
